// ================================================================
// build.gradle.kts — Quality Gates config for Java 21 (Kotlin DSL)
// ================================================================
// Use this instead of build.gradle if your project uses Kotlin DSL.
// ================================================================

import org.gradle.testing.jacoco.tasks.JacocoReport

plugins {
    java
    jacoco
    id("org.sonarqube") version "5.0.0.4638"
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(21))
    }
}

// ── Integration test source set ─────────────────────────────
sourceSets {
    create("integrationTest") {
        java.srcDir("src/integrationTest/java")
        resources.srcDir("src/integrationTest/resources")
        compileClasspath += sourceSets.main.get().output + sourceSets.test.get().output
        runtimeClasspath += sourceSets.main.get().output + sourceSets.test.get().output
    }
}

val integrationTestImplementation by configurations.getting {
    extendsFrom(configurations.testImplementation.get())
}
val integrationTestRuntimeOnly by configurations.getting {
    extendsFrom(configurations.testRuntimeOnly.get())
}

// ── GATE 1: Unit tests ───────────────────────────────────────
tasks.test {
    useJUnitPlatform()
    exclude("**/*IT.class", "**/*IntegrationTest.class")
    finalizedBy(tasks.jacocoTestReport)
    testLogging {
        events("passed", "skipped", "failed")
    }
}

tasks.jacocoTestReport {
    dependsOn(tasks.test)
    reports {
        xml.required.set(true)
        html.required.set(true)
        xml.outputLocation.set(layout.buildDirectory.file("reports/jacoco/test/jacocoTestReport.xml"))
    }
}

tasks.jacocoTestCoverageVerification {
    dependsOn(tasks.jacocoTestReport)
    violationRules {
        rule {
            limit {
                counter = "LINE"
                value   = "COVEREDRATIO"
                minimum = "0.80".toBigDecimal()
            }
        }
        rule {
            limit {
                counter = "BRANCH"
                value   = "COVEREDRATIO"
                minimum = "0.75".toBigDecimal()
            }
        }
    }
}

tasks.check {
    dependsOn(tasks.jacocoTestCoverageVerification)
}

// ── GATE 2: Integration tests ────────────────────────────────
val integrationTest = task<Test>("integrationTest") {
    description = "Runs integration tests"
    group = "verification"
    testClassesDirs = sourceSets["integrationTest"].output.classesDirs
    classpath = sourceSets["integrationTest"].runtimeClasspath
    useJUnitPlatform()
    shouldRunAfter(tasks.test)
    testLogging {
        events("passed", "skipped", "failed")
    }
}

val jacocoIntegrationTestReport = task<JacocoReport>("jacocoIntegrationTestReport") {
    dependsOn(integrationTest)
    executionData(integrationTest)
    sourceSets(sourceSets.main.get())
    reports {
        xml.required.set(true)
        html.required.set(true)
        xml.outputLocation.set(layout.buildDirectory.file("reports/jacoco/integrationTest/jacocoIntegrationTestReport.xml"))
    }
}

integrationTest.finalizedBy(jacocoIntegrationTestReport)

// ── GATE 3: SonarQube ─────────────────────────────────────────
sonarqube {
    properties {
        property("sonar.projectKey", System.getenv("SONAR_PROJECT_KEY") ?: "your-project-key")
        property("sonar.host.url",   System.getenv("SONAR_HOST_URL") ?: "http://localhost:9000")
        property("sonar.java.source", "21")
        property(
            "sonar.coverage.jacoco.xmlReportPaths",
            "${layout.buildDirectory.get()}/reports/jacoco/test/jacocoTestReport.xml," +
            "${layout.buildDirectory.get()}/reports/jacoco/integrationTest/jacocoIntegrationTestReport.xml"
        )
        property("sonar.exclusions", "**/generated/**,**/*Application.java,**/dto/**,**/model/**")
        property("sonar.coverage.exclusions", "**/generated/**,**/*Config.java,**/dto/**,**/model/**")
    }
}

tasks.sonar {
    dependsOn(tasks.jacocoTestReport, jacocoIntegrationTestReport)
}
