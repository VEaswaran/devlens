"""
agents/spanner_agent.py
────────────────────────
Google Cloud Spanner specific review:
  • Transaction management (ABORTED retry, missing commit)
  • Query patterns (N+1, SELECT *, no pagination, string concat SQL)
  • Performance (mutations vs DML, hotspot keys, full table scans)
  • Error handling (SpannerException, DeadlineExceeded, ABORTED)
  • Resource management (try-with-resources, connection pool)
"""

import os
import sys
import re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "shared"))

from agent_utils import (
    load_config, call_claude, parse_claude_json,
    get_git_diff, format_diff_for_prompt, post_pr_comment,
)

SYSTEM_PROMPT = """You are a Google Cloud Spanner expert and Java architect.
Review the Java code changes for Spanner-specific issues.
Only report Spanner-related findings — skip general Java issues (another agent handles those).
Be SPECIFIC — reference exact class names, method names, line hints.

Check these Spanner patterns:

━━━ TRANSACTIONS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ReadWriteTransaction missing retry on ABORTED status → CRITICAL
  Pattern to flag: runInTransaction without catching SpannerException with ABORTED code
• Missing commit() call in manual transaction → CRITICAL
• No error handling around TransactionRunner → ERROR
• Using ReadWriteTransaction for read-only operations → WARNING (use ReadOnlyTransaction)
• Long-running transactions holding locks → WARNING

━━━ QUERIES & DML ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• SELECT * in Spanner queries → ERROR (always specify columns for performance)
• String concatenation in SQL: "SELECT ... WHERE id = " + id → CRITICAL (injection + no plan caching)
• Missing LIMIT on reads that could return large result sets → ERROR
• Loop executing individual reads/writes → N+1 pattern → ERROR (use batch or single query)
• DML (executeUpdate) for bulk operations → WARNING (prefer Mutations for bulk)
• Missing index hints on filtered queries on non-key columns → WARNING

━━━ PERFORMANCE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• UUID.randomUUID() or auto-increment as primary key → WARNING (hotspot — use hash prefix)
• Individual Mutation.newInsertBuilder() in a loop without batch → ERROR
  Should use: List<Mutation> and dbClient.write(mutations)
• Stale read without explicit TimestampBound → INFO
• No connection pool configuration → WARNING
• Reading same row multiple times in same request → WARNING (cache it)

━━━ ERROR HANDLING ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• SpannerException not caught specifically → ERROR (catching generic Exception instead)
• ErrorCode.ABORTED not handled with retry logic → CRITICAL
• DeadlineExceededException not handled → ERROR
• No retry with exponential backoff on transient errors → WARNING
• Spanner client not closed → WARNING (resource leak, though usually managed)

━━━ RESOURCE MANAGEMENT ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ResultSet not closed after use → ERROR (use try-with-resources)
• DatabaseClient obtained inside a loop → ERROR (should be singleton/injected)
• SpannerOptions built multiple times → WARNING (expensive, should be singleton)

Respond ONLY with JSON:
{
  "result": "<passed|failed>",
  "has_spanner_code": <true|false>,
  "critical_count": <int>,
  "error_count": <int>,
  "warning_count": <int>,
  "findings": [
    {
      "category": "<transaction|query|performance|error_handling|resource>",
      "severity": "<critical|error|warning|info>",
      "file": "<filename.java>",
      "method": "<ClassName.methodName or null>",
      "line_hint": "<line or range>",
      "title": "<short title>",
      "detail": "<specific code reference>",
      "fix": "<concrete fix with Spanner API example>"
    }
  ],
  "summary": "<2-3 sentences on Spanner usage quality>"
}
result = "failed" if has_spanner_code AND (critical_count > 0 OR error_count > 1)
result = "passed" if no Spanner code found OR all checks pass."""


def run():
    config = load_config()
    base   = config.get("global", {}).get("diff_base_branch", "develop")

    diff_data = get_git_diff(base)
    diff_text = format_diff_for_prompt(diff_data)

    # Quick check: does this PR even touch Spanner?
    spanner_keywords = ["spanner", "DatabaseClient", "Mutation", "ReadWriteTransaction",
                        "ReadOnlyTransaction", "TransactionRunner", "SpannerException",
                        "com.google.cloud.spanner", "Statement.of", "ResultSet"]

    all_content = " ".join(diff_data.get("file_contents", {}).values()).lower()
    has_spanner = any(kw.lower() in all_content for kw in spanner_keywords)

    if not has_spanner:
        print("No Spanner code detected. Posting pass.")
        body = [
            "## 🗄️ Spanner Review — ✅ PASSED",
            "",
            "_No Google Cloud Spanner code detected in this PR._",
        ]
        post_pr_comment("\n".join(body))
        _write_result("passed", "No Spanner code in this PR.")
        return

    print(f"Spanner code detected — running deep review...")

    user_prompt = f"""
Review these Java changes for Google Cloud Spanner issues.
Base branch: {base}

{diff_text}

Be specific. Reference actual Spanner API calls visible in the diff.
If you see TransactionRunner, ReadWriteTransaction, Mutation, DatabaseClient, Statement — examine them closely.
"""

    try:
        raw      = call_claude(SYSTEM_PROMPT, user_prompt, max_tokens=3000)
        analysis = parse_claude_json(raw)
    except Exception as e:
        print(f"Claude error: {e}")
        analysis = {
            "result": "passed", "has_spanner_code": True,
            "critical_count": 0, "error_count": 0, "warning_count": 0,
            "findings": [], "summary": "Analysis unavailable.",
        }

    result = analysis.get("result", "passed")
    icon   = "✅" if result == "passed" else "❌"

    sev_icon = {"critical": "🔴", "error": "🟠", "warning": "🟡", "info": "🔵"}
    cat_labels = {
        "transaction":     "🔄 Transactions",
        "query":           "🔍 Queries & DML",
        "performance":     "⚡ Performance",
        "error_handling":  "🚨 Error Handling",
        "resource":        "♻️ Resource Management",
    }

    grouped = {}
    for f in analysis.get("findings", []):
        cat = f.get("category", "query")
        grouped.setdefault(cat, []).append(f)

    sections = []
    for cat_key, label in cat_labels.items():
        findings = grouped.get(cat_key, [])
        if not findings:
            continue
        rows = []
        for f in findings:
            si  = sev_icon.get(f.get("severity", "info"), "🔵")
            loc = f.get("file", "")
            if f.get("method"):
                loc += f" → `{f['method']}`"
            rows.append(f"| {si} {f.get('severity','').upper()} | `{loc}` | **{f.get('title','')}** |")

        section = [
            f"### {label}",
            "| Severity | Location | Issue |",
            "|----------|----------|-------|",
            *rows,
        ]
        # Detail block for critical/error
        for f in findings:
            if f.get("severity") in ("critical", "error"):
                section.append(f"\n> **{f.get('title')}**")
                section.append(f"> {f.get('detail','')}")
                if f.get("fix"):
                    section.append(f">\n> 💡 **Fix:** `{f.get('fix')}`")
        sections.append("\n".join(section))

    counts = (
        f"🔴 **{analysis.get('critical_count',0)} Critical** &nbsp;|&nbsp; "
        f"🟠 **{analysis.get('error_count',0)} Errors** &nbsp;|&nbsp; "
        f"🟡 **{analysis.get('warning_count',0)} Warnings**"
    )

    body = "\n\n".join(filter(None, [
        f"## 🗄️ Spanner Review — {icon} {result.upper()}",
        f"**Branch diff:** `origin/{base}...HEAD`",
        counts,
        *sections,
        f"### Summary\n{analysis.get('summary','')}",
        "> ⚠️ **Action required:** Fix all Spanner CRITICAL/ERROR issues before merge." if result == "failed" else "> ✅ Spanner usage looks correct.",
    ]))

    post_pr_comment(body)
    _write_result(result, analysis.get("summary", ""))

    if result == "failed":
        sys.exit(1)


def _write_result(result, summary):
    lines = [f"SPANNER_RESULT={result}", f"SPANNER_SUMMARY={summary[:200]}"]
    with open("/tmp/spanner_result.env", "w") as f:
        f.write("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    run()
