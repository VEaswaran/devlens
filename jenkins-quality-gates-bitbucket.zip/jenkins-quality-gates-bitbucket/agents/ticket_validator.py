"""
agents/ticket_validator.py
───────────────────────────
Validates PR against linked Jira ticket:
  • Ticket ID present in PR title / branch / body
  • Fetches acceptance criteria from Jira
  • Claude checks if the diff satisfies each AC
"""

import os
import sys
import base64
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "shared"))

import requests as req
from agent_utils import (
    load_config, call_claude, parse_claude_json,
    get_git_diff, format_diff_for_prompt, post_pr_comment,
)

SYSTEM_PROMPT = """You are a senior engineering lead validating a PR against its Jira ticket.
Check: does the code diff satisfy ALL acceptance criteria? Is the PR description clear?
Are there unrelated changes? Respond ONLY with valid JSON."""


def run():
    config    = load_config()
    cfg       = config.get("ticket_validator", {})
    ticket_id = os.environ.get("TICKET_ID", "").strip()
    pr_title  = os.environ.get("PR_TITLE", "")
    base      = config.get("global", {}).get("diff_base_branch", "develop")

    if not ticket_id:
        body = "\n".join([
            "## 🎫 Ticket Validator — ❌ FAILED",
            "",
            "**No ticket ID found** in PR title, branch name, or description.",
            "",
            "Include a ticket reference like `PROJ-1234` in your PR title.",
            "> Example: `feat(PROJ-1234): Add real-time notification service`",
            "",
            "> ⚠️ **Action required:** Update PR title to include a valid ticket ID.",
        ])
        post_pr_comment(body)
        _write_result("failed", "0", "No ticket ID found")
        sys.exit(1)

    # ── Fetch Jira ticket ────────────────────────────────────
    ticket = _fetch_jira(ticket_id)

    # ── Get diff ─────────────────────────────────────────────
    diff_data = get_git_diff(base)
    diff_text = format_diff_for_prompt(diff_data, max_chars=12000)

    user_prompt = f"""
Ticket ID: {ticket_id}
Ticket Summary: {ticket.get('summary', 'Not available')}
Ticket Description: {ticket.get('description', 'Not available')}
Acceptance Criteria:
{ticket.get('acceptance_criteria', '(Not available — infer from ticket summary)')}

PR Title: {pr_title}

Code changes (develop...HEAD):
{diff_text}

Evaluate and respond with JSON:
{{
  "score": <0-100 how well PR satisfies ticket>,
  "result": "<passed|failed>",
  "ac_results": [
    {{ "criterion": "<AC text>", "satisfied": <true|false>, "evidence": "<file/method or explanation>" }}
  ],
  "issues": [
    {{ "severity": "<error|warning|info>", "message": "<actionable message>" }}
  ],
  "summary": "<2-3 sentence overall assessment>"
}}
result=failed if score < {cfg.get('rules',{}).get('acceptance_criteria_match',{}).get('min_score',80)}
"""

    try:
        raw      = call_claude(SYSTEM_PROMPT, user_prompt, max_tokens=1500)
        analysis = parse_claude_json(raw)
    except Exception as e:
        print(f"Claude error: {e}")
        analysis = {"score": 50, "result": "passed", "ac_results": [], "issues": [], "summary": "Analysis unavailable."}

    result  = analysis.get("result", "passed")
    score   = analysis.get("score", 0)
    icon    = "✅" if result == "passed" else "❌"

    jira_url  = os.environ.get("JIRA_BASE_URL", "")
    ticket_lnk = f"[{ticket_id}]({jira_url}/browse/{ticket_id})" if jira_url else ticket_id

    ac_rows = ["| Status | Acceptance Criterion | Evidence |", "|--------|----------------------|----------|"]
    for ac in analysis.get("ac_results", []):
        ac_rows.append(f"| {'✅' if ac.get('satisfied') else '❌'} | {ac.get('criterion','')} | {ac.get('evidence','')} |")

    issue_lines = "\n".join(
        f"- {'🔴' if i['severity']=='error' else '🟡' if i['severity']=='warning' else '🔵'} {i['message']}"
        for i in analysis.get("issues", [])
    )

    body = "\n\n".join(filter(None, [
        f"## 🎫 Ticket Validator — {icon} {result.upper()}",
        f"**Ticket:** {ticket_lnk} · {ticket.get('summary','')}\n**Match Score:** {score}/100",
        "### Acceptance Criteria\n" + "\n".join(ac_rows) if analysis.get("ac_results") else "",
        f"### Issues Found\n{issue_lines}" if issue_lines else "",
        f"### Summary\n{analysis.get('summary','')}",
        "> ⚠️ **Action required:** Address the above issues and push a new commit." if result == "failed"
        else "> 🎉 PR satisfies ticket requirements.",
    ]))

    post_pr_comment(body)
    _write_result(result, str(score), "; ".join(i["message"] for i in analysis.get("issues", [])))

    if result == "failed":
        sys.exit(1)


def _fetch_jira(ticket_id: str) -> dict:
    base_url = os.environ.get("JIRA_BASE_URL", "")
    email    = os.environ.get("JIRA_EMAIL", "")
    token    = os.environ.get("JIRA_TOKEN", "")

    if not base_url or not token:
        return {"summary": ticket_id, "description": "", "acceptance_criteria": ""}

    try:
        creds = base64.b64encode(f"{email}:{token}".encode()).decode()
        r = req.get(
            f"{base_url}/rest/api/3/issue/{ticket_id}",
            headers={"Authorization": f"Basic {creds}", "Accept": "application/json"},
            timeout=15,
        )
        r.raise_for_status()
        data = r.json()
        fields = data.get("fields", {})

        desc_blocks = fields.get("description", {})
        description = ""
        if isinstance(desc_blocks, dict):
            for block in desc_blocks.get("content", []):
                for inner in block.get("content", []):
                    description += inner.get("text", "") + " "

        ac = fields.get("acceptance_criteria") or fields.get("customfield_10016") or ""

        return {
            "summary":              fields.get("summary", ""),
            "description":          description.strip(),
            "acceptance_criteria":  str(ac),
            "status":               fields.get("status", {}).get("name", ""),
        }
    except Exception as e:
        print(f"Jira fetch error: {e}")
        return {"summary": ticket_id, "description": "", "acceptance_criteria": ""}


def _write_result(result, score, findings):
    lines = [f"TICKET_RESULT={result}", f"TICKET_SCORE={score}", f"TICKET_FINDINGS={findings[:200]}"]
    with open("/tmp/ticket_result.env", "w") as f:
        f.write("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    run()
