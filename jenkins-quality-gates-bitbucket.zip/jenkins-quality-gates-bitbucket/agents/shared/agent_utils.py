"""
agents/shared/agent_utils.py
────────────────────────────
Shared helpers for AI review agents — Bitbucket Cloud version.

Auth note: Bitbucket Cloud API tokens use Basic Auth with your
Atlassian account EMAIL as username, API TOKEN as password.
(Not your Bitbucket username/App Password — those are deprecated.)
"""

import os
import re
import json
import base64
import subprocess
import yaml
import requests
from pathlib import Path
from typing import Optional


# ── Config ───────────────────────────────────────────────────

def load_config() -> dict:
    workspace = os.environ.get("WORKSPACE") or os.environ.get("GITHUB_WORKSPACE") or "."
    config_path = Path(workspace) / "config" / "agent-config.yml"
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ── Claude API ───────────────────────────────────────────────

def call_claude(system_prompt: str, user_prompt: str, max_tokens: int = 3000) -> str:
    api_key = os.environ["ANTHROPIC_API_KEY"]
    response = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        json={
            "model": "claude-opus-4-5",
            "max_tokens": max_tokens,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        },
        timeout=120,
    )
    response.raise_for_status()
    return response.json()["content"][0]["text"]


def parse_claude_json(text: str) -> dict:
    clean = re.sub(r"```json\n?", "", text)
    clean = re.sub(r"```\n?", "", clean).strip()
    return json.loads(clean)


# ── Git Diff (develop vs current branch) ────────────────────

def get_git_diff(base_branch: str = "develop") -> dict:
    workspace = os.environ.get("WORKSPACE") or "."
    try:
        subprocess.run(["git", "fetch", "origin", base_branch],
                        cwd=workspace, capture_output=True, check=False)

        result = subprocess.run(
            ["git", "diff", f"origin/{base_branch}...HEAD", "--name-status"],
            cwd=workspace, capture_output=True, text=True, check=True
        )
        changed_files = []
        for line in result.stdout.strip().splitlines():
            if not line.strip():
                continue
            parts = line.split("\t", 1)
            if len(parts) == 2:
                status, filepath = parts
                changed_files.append({"status": status.strip(), "path": filepath.strip()})

        file_diffs = {}
        for entry in changed_files:
            fpath = entry["path"]
            if not fpath.endswith(".java"):
                continue
            diff_result = subprocess.run(
                ["git", "diff", f"origin/{base_branch}...HEAD", "--", fpath],
                cwd=workspace, capture_output=True, text=True, check=False
            )
            if diff_result.stdout:
                file_diffs[fpath] = diff_result.stdout[:15000]

        log_result = subprocess.run(
            ["git", "log", f"origin/{base_branch}..HEAD", "--oneline"],
            cwd=workspace, capture_output=True, text=True, check=False
        )
        commits = log_result.stdout.strip().splitlines()

        file_contents = {}
        for entry in changed_files:
            fpath = entry["path"]
            if not fpath.endswith(".java") or entry["status"] == "D":
                continue
            full_path = Path(workspace) / fpath
            if full_path.exists():
                content = full_path.read_text(encoding="utf-8", errors="ignore")
                file_contents[fpath] = content[:20000]

        return {
            "base_branch": base_branch,
            "changed_files": changed_files,
            "java_files": [f for f in changed_files if f["path"].endswith(".java")],
            "file_diffs": file_diffs,
            "file_contents": file_contents,
            "commits": commits,
            "total_java_files": len([f for f in changed_files if f["path"].endswith(".java")]),
        }
    except subprocess.CalledProcessError as e:
        print(f"Git diff error: {e}")
        return {"base_branch": base_branch, "changed_files": [], "java_files": [],
                "file_diffs": {}, "file_contents": {}, "commits": [], "total_java_files": 0}


def format_diff_for_prompt(diff_data: dict, max_chars: int = 30000) -> str:
    lines = [
        f"Base branch: {diff_data['base_branch']}",
        f"Changed Java files: {diff_data['total_java_files']}",
        "", "=== Commits on this branch ===",
        *diff_data.get("commits", []),
        "", "=== Changed files ===",
        *[f"  [{f['status']}] {f['path']}" for f in diff_data.get("changed_files", [])],
        "",
    ]
    for filepath, diff in diff_data.get("file_diffs", {}).items():
        lines.append(f"\n{'='*60}\nFILE: {filepath}\n--- DIFF (develop...HEAD) ---")
        lines.append(diff[:8000])
    for filepath, content in list(diff_data.get("file_contents", {}).items())[:5]:
        lines.append(f"\n{'='*60}\nFILE CONTENT: {filepath}")
        lines.append(content[:6000])
    return "\n".join(lines)[:max_chars]


# ── Bitbucket Cloud API ──────────────────────────────────────
# Docs: https://developer.atlassian.com/cloud/bitbucket/rest/

def _bb_auth_header() -> dict:
    email = os.environ["BITBUCKET_EMAIL"]
    token = os.environ["BITBUCKET_TOKEN"]
    creds = base64.b64encode(f"{email}:{token}".encode()).decode()
    return {"Authorization": f"Basic {creds}", "Content-Type": "application/json"}


def _bb_base() -> str:
    return "https://api.bitbucket.org/2.0"


def _workspace() -> str:
    return os.environ.get("BITBUCKET_WORKSPACE", "")


def _repo_slug() -> str:
    return os.environ.get("BITBUCKET_REPO_SLUG", "")


def _pr_id() -> str:
    return os.environ.get("PR_NUMBER", "0")


def post_pr_comment(body: str) -> dict:
    """
    Post or update a PR comment. Bitbucket Cloud has no simple
    'find by prefix' listing shortcut like GitHub, so we page through
    existing comments to find one from this pipeline (by prefix match)
    and update it; otherwise create a new one.
    """
    existing_id = _find_existing_comment(body[:50])
    url_base = f"{_bb_base()}/repositories/{_workspace()}/{_repo_slug()}/pullrequests/{_pr_id()}/comments"

    payload = {"content": {"raw": body}}

    if existing_id:
        r = requests.put(f"{url_base}/{existing_id}", headers=_bb_auth_header(),
                          json=payload, timeout=30)
    else:
        r = requests.post(url_base, headers=_bb_auth_header(), json=payload, timeout=30)
    r.raise_for_status()
    return r.json()


def _find_existing_comment(prefix: str) -> Optional[int]:
    try:
        url = f"{_bb_base()}/repositories/{_workspace()}/{_repo_slug()}/pullrequests/{_pr_id()}/comments"
        r = requests.get(url, headers=_bb_auth_header(), params={"pagelen": 50}, timeout=30)
        for c in r.json().get("values", []):
            raw = c.get("content", {}).get("raw", "")
            if raw.startswith(prefix):
                return c["id"]
    except Exception:
        pass
    return None


def set_commit_status(state: str, description: str, key: str = "ai-pr-review",
                       name: str = "AI PR Review"):
    """
    state must be one of: SUCCESSFUL | FAILED | INPROGRESS | STOPPED
    (Bitbucket Cloud uses different state names than GitHub's success/failure/pending)
    """
    sha = os.environ.get("PR_SHA", "")
    if not sha:
        return
    state_map = {"success": "SUCCESSFUL", "failure": "FAILED", "pending": "INPROGRESS"}
    bb_state = state_map.get(state, state.upper())

    url = f"{_bb_base()}/repositories/{_workspace()}/{_repo_slug()}/commit/{sha}/statuses/build"
    requests.post(url, headers=_bb_auth_header(), json={
        "state": bb_state,
        "key": key,
        "name": name,
        "description": description[:255],
        "url": os.environ.get("BUILD_URL", ""),
    }, timeout=30)


def set_label(label: str, add: bool = True):
    """
    Bitbucket Cloud PRs don't support labels natively (no label API).
    This is a no-op kept for interface compatibility with the
    GitHub/Jenkins agent code — use PR comments or a custom status
    key instead to signal review state.
    """
    pass


def get_pr_info() -> dict:
    url = f"{_bb_base()}/repositories/{_workspace()}/{_repo_slug()}/pullrequests/{_pr_id()}"
    r = requests.get(url, headers=_bb_auth_header(), timeout=30)
    r.raise_for_status()
    return r.json()
