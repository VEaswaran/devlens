"""
agents/aggregator.py
─────────────────────
Reads result env files from all agents,
posts a combined PR summary, sets labels and commit status.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "shared"))

from agent_utils import post_pr_comment, set_commit_status, set_label


def _read_env_file(path: str) -> dict:
    result = {}
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if "=" in line:
                    k, v = line.split("=", 1)
                    result[k] = v
    except FileNotFoundError:
        pass
    return result


def run():
    pr_number = os.environ.get("PR_NUMBER", "?")
    pr_title  = os.environ.get("PR_TITLE",  "")
    pr_author = os.environ.get("PR_AUTHOR", "")
    pr_sha    = os.environ.get("PR_SHA", "")[:7]
    pr_branch = os.environ.get("PR_BRANCH", "")

    # Read each agent's result file
    ticket  = _read_env_file("/tmp/ticket_result.env")
    java    = _read_env_file("/tmp/java_review_result.env")
    spanner = _read_env_file("/tmp/spanner_result.env")

    agents = [
        {"name": "🎫 Ticket Validator", "result": ticket.get("TICKET_RESULT", "skipped"),  "blocking": True,  "extra": f"Score: {ticket.get('TICKET_SCORE','—')}/100"},
        {"name": "☕ Java 21 Review",   "result": java.get("JAVA_RESULT", "skipped"),       "blocking": True,  "extra": f"🔴 {java.get('JAVA_CRITICAL','0')} critical · 🟠 {java.get('JAVA_ERRORS','0')} errors · 🟡 {java.get('JAVA_WARNINGS','0')} warnings"},
        {"name": "🗄️ Spanner Review",  "result": spanner.get("SPANNER_RESULT", "skipped"), "blocking": True,  "extra": ""},
    ]

    failed  = [a for a in agents if a["blocking"] and a["result"] == "failed"]
    overall = "passed" if not failed else "failed"
    icon    = "✅" if overall == "passed" else "❌"

    # Table rows
    rows = []
    for a in agents:
        r = a["result"]
        ri = "✅ Passed" if r == "passed" else "❌ Failed" if r == "failed" else "⏭️ Skipped"
        rows.append(f"| {a['name']} | {ri} | {a['extra']} |")

    failures_detail = ""
    if failed:
        lines = ["### ❌ What needs fixing\n"]
        for a in failed:
            lines.append(f"**{a['name']}** — see detailed agent comment above ↑")
        failures_detail = "\n".join(lines)

    body = "\n\n".join(filter(None, [
        f"# {icon} AI PR Review — {overall.upper()}",
        f"**PR:** #{pr_number} · {pr_title}\n**Author:** @{pr_author} &nbsp;|&nbsp; **Branch:** `{pr_branch}` &nbsp;|&nbsp; **Commit:** `{pr_sha}`",
        "\n".join([
            "## Agent Results",
            "| Agent | Status | Details |",
            "|-------|--------|---------|",
            *rows,
        ]),
        failures_detail,
        "\n".join([
            "## Next Steps" if overall == "failed" else "## 🎉 All Checks Passed",
            *(["1. Scroll up — each agent posted a detailed comment with exact issues",
               "2. Fix all 🔴 Critical and 🟠 Error findings",
               "3. Push a new commit — all agents re-run automatically",
               "4. Mark each resolved agent comment as **Resolved** on GitHub",
               "",
               "> 🔒 **Merge is blocked** until all agents pass."] if overall == "failed"
              else ["All agents passed. This PR is ready for human reviewer approval."]),
        ]),
        f"---\n<sub>🤖 AI PR Review · Java 21 + Spanner · Run #{os.environ.get('BUILD_NUMBER','?')}</sub>",
    ]))

    post_pr_comment(body)

    # Labels
    if overall == "passed":
        set_label("ai-approved",   add=True)
        set_label("needs-changes", add=False)
    else:
        set_label("needs-changes", add=True)
        set_label("ai-approved",   add=False)

    # Commit status
    set_commit_status(
        "success" if overall == "passed" else "failure",
        "All AI agents passed ✓" if overall == "passed"
        else f"Failed: {', '.join(a['name'] for a in failed)}",
    )

    # Write for Teams
    with open("/tmp/aggregate_result.env", "w") as f:
        f.write(f"OVERALL_RESULT={overall}\n")
        f.write(f"FAILED_AGENTS={', '.join(a['name'] for a in failed)}\n")
        f.write(f"JAVA_CRITICAL={java.get('JAVA_CRITICAL','0')}\n")
        f.write(f"JAVA_ERRORS={java.get('JAVA_ERRORS','0')}\n")

    print(f"Overall: {overall}")
    if overall == "failed":
        sys.exit(1)


if __name__ == "__main__":
    run()
