"""
agents/java_review_agent.py
────────────────────────────
Deep Java 21 code review agent covering:
  • Code smells (God class, long methods, magic numbers, deep nesting...)
  • Error handling (no suppression, no empty catch, proper exception hierarchy)
  • Null pointer safety (Optional, @NonNull, Objects.requireNonNull)
  • Cyclomatic + cognitive complexity
  • Test coverage (error scenarios, null scenarios, branch coverage)
  • Java 21 best practices (records, sealed, pattern matching, switch expr)

Runs git diff develop...HEAD to get the actual branch changes.
"""

import os
import sys
import json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "shared"))

from agent_utils import (
    load_config, call_claude, parse_claude_json,
    get_git_diff, format_diff_for_prompt, post_pr_comment,
    set_commit_status,
)

SYSTEM_PROMPT = """You are a principal Java engineer with 15+ years of experience reviewing Java 21 code.
You are STRICT, THOROUGH, and SPECIFIC. You never give generic feedback.
You always reference exact file names, line numbers (from the diff), method names, and class names.

Your review covers these dimensions — report ALL issues found, do NOT skip any:

━━━ 1. ERROR HANDLING (Zero Tolerance) ━━━━━━━━━━━━━━━━━━━━━━━━━
• Empty catch blocks: catch(Exception e) {} — ALWAYS flag as CRITICAL
• Suppressed exceptions: catch that only logs and swallows without rethrowing — flag as ERROR
• Generic exception catches: catch(Exception e) or catch(Throwable t) without good reason — flag
• Exception swallowing: catching checked exception and returning null/default silently — CRITICAL
• Missing finally/try-with-resources for AutoCloseable resources — ERROR
• Throwing generic new Exception("message") instead of domain-specific exceptions — WARNING
• No error propagation: error caught at wrong layer, not propagated to caller — ERROR

━━━ 2. NULL POINTER SAFETY ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Direct dereference of method return values without null check — ERROR
• Missing null checks on constructor/method parameters — ERROR  
• Returning null from public methods instead of Optional<T> — WARNING
• Not using Objects.requireNonNull() for mandatory constructor params — WARNING
• Missing @NonNull/@Nullable annotations on public APIs — INFO
• Chained method calls on potentially null objects (a.getB().getC()) — ERROR
• Comparing objects with == instead of .equals() — ERROR
• Not checking Optional.isPresent() before Optional.get() — CRITICAL

━━━ 3. CYCLOMATIC COMPLEXITY ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Count branches: each if/else/switch case/catch/for/while/&&/|| adds 1
• Complexity > 10: BLOCKING ERROR
• Complexity 7-10: WARNING  
• Deeply nested blocks > 4 levels: ERROR
• Complex boolean expressions (> 3 conditions): suggest extraction to named method
• Long methods > 40 lines: ERROR (cognitive load)

━━━ 4. CODE SMELLS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• God class: class with > 15 fields or > 20 methods — ERROR
• Long parameter list: > 5 params — suggest builder/parameter object — WARNING
• Feature envy: method uses more of another class than its own — WARNING
• Data clumps: same group of fields/params appearing together repeatedly — WARNING
• Primitive obsession: using String for email/phone/id instead of value types — WARNING
• Dead code: unused private methods, unreachable code after return — ERROR
• Magic numbers/strings: unexplained numeric/string literals — WARNING
• Duplicate code: same logic copy-pasted — ERROR
• Comments that explain WHAT not WHY (code should be self-documenting) — INFO

━━━ 5. TEST COVERAGE ANALYSIS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
For every changed method/class, check if there are corresponding test changes:
• Happy path tested? 
• Error/exception scenarios tested? (what if service throws? what if DB fails?)
• Null input scenarios tested? (passing null to each parameter)
• Boundary conditions tested? (empty list, max value, min value)
• Each if/else branch covered?
• Each catch block exercised by a test?
If test file NOT in the diff for a changed source file: flag as ERROR

━━━ 6. JAVA 21 BEST PRACTICES ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• POJO with only getters/setters/equals/hashCode → suggest record — INFO
• instanceof with cast: if (x instanceof Foo) { Foo f = (Foo)x } → pattern matching — WARNING
• Multi-branch type check → suggest sealed class + switch expression — INFO  
• String.format() for multi-line → text block — INFO
• Imperative loop that builds a collection → Stream API — INFO
• Thread() constructor for I/O tasks → virtual thread (Thread.ofVirtual()) — INFO
• Switch statement → switch expression where return value used — INFO

Respond ONLY with this exact JSON structure — no extra text:
{
  "result": "<passed|failed>",
  "critical_count": <int>,
  "error_count": <int>,
  "warning_count": <int>,
  "info_count": <int>,
  "findings": [
    {
      "category": "<error_handling|null_safety|complexity|code_smell|test_coverage|java21>",
      "severity": "<critical|error|warning|info>",
      "file": "<filename.java>",
      "method": "<ClassName.methodName or null>",
      "line_hint": "<approximate line number or range from diff, or null>",
      "title": "<short title, max 80 chars>",
      "detail": "<specific explanation referencing actual code from the diff>",
      "fix": "<concrete fix suggestion with example code snippet if helpful>"
    }
  ],
  "complexity_report": [
    {
      "file": "<filename.java>",
      "method": "<ClassName.methodName>",
      "estimated_complexity": <int>,
      "verdict": "<ok|warn|block>"
    }
  ],
  "test_coverage_report": {
    "changed_source_files": ["<file1>", "<file2>"],
    "test_files_found": ["<test1>", "<test2>"],
    "missing_test_files": ["<source_file_with_no_test>"],
    "untested_scenarios": ["<description of missing test scenario>"]
  },
  "summary": "<3-4 sentence assessment of the overall code quality>"
}

result = "failed" if critical_count > 0 OR error_count > 2 OR missing_test_files is non-empty.
Be extremely specific — reference actual code, actual method names, actual line ranges from the diff."""


def run():
    config = load_config()
    cfg    = config.get("java_review", {})
    base   = config.get("global", {}).get("diff_base_branch", "develop")

    # ── Get git diff develop...HEAD ──────────────────────────
    print(f"Getting git diff: origin/{base}...HEAD")
    diff_data  = get_git_diff(base)
    diff_text  = format_diff_for_prompt(diff_data)

    if diff_data["total_java_files"] == 0:
        print("No Java files changed. Skipping Java review.")
        _write_result("passed", "0", "0", "0", "No Java files changed.")
        return

    print(f"Reviewing {diff_data['total_java_files']} Java file(s)...")

    user_prompt = f"""
Review the following Java 21 code changes (diff of current branch vs {base}).

{diff_text}

Config thresholds:
- Max cyclomatic complexity: {cfg.get('cyclomatic_complexity', {}).get('max_per_method', 10)}
- Max method lines: {cfg.get('code_smells', {}).get('max_method_lines', 40)}
- Max class lines: {cfg.get('code_smells', {}).get('max_class_lines', 400)}
- Max parameters: {cfg.get('code_smells', {}).get('max_parameters', 5)}
- Java version: 21

Be SPECIFIC. Reference actual class names, method names, and line numbers from the diff above.
If a catch block is empty or swallows an exception, quote the exact code.
If a null dereference risk exists, show the exact chain.
"""

    try:
        raw      = call_claude(SYSTEM_PROMPT, user_prompt, max_tokens=4000)
        analysis = parse_claude_json(raw)
    except Exception as e:
        print(f"Claude error: {e}")
        analysis = {
            "result": "passed", "critical_count": 0, "error_count": 0,
            "warning_count": 0, "info_count": 0,
            "findings": [], "complexity_report": [],
            "test_coverage_report": {"changed_source_files": [], "test_files_found": [], "missing_test_files": [], "untested_scenarios": []},
            "summary": "Analysis unavailable due to API error.",
        }

    # ── Build PR comment ─────────────────────────────────────
    result = analysis.get("result", "passed")
    icon   = "✅" if result == "passed" else "❌"

    # Group findings by category
    cats = {
        "error_handling": ("🚨 Error Handling", []),
        "null_safety":    ("🔴 Null Safety",     []),
        "complexity":     ("🔀 Cyclomatic Complexity", []),
        "code_smell":     ("🧹 Code Smells",     []),
        "test_coverage":  ("🧪 Test Coverage",   []),
        "java21":         ("☕ Java 21 Practices", []),
    }
    for f in analysis.get("findings", []):
        cat = f.get("category", "code_smell")
        if cat in cats:
            cats[cat][1].append(f)

    sev_icon = {"critical": "🔴", "error": "🟠", "warning": "🟡", "info": "🔵"}

    sections = []
    for cat_key, (cat_label, findings) in cats.items():
        if not findings:
            continue
        rows = []
        for f in findings:
            si      = sev_icon.get(f.get("severity", "info"), "🔵")
            loc     = f.get("file", "")
            if f.get("method"):
                loc += f" → `{f['method']}`"
            if f.get("line_hint"):
                loc += f" (L{f['line_hint']})"
            rows.append(f"| {si} {f.get('severity','').upper()} | {loc} | **{f.get('title','')}** |")

        section = [
            f"### {cat_label}",
            "| Severity | Location | Issue |",
            "|----------|----------|-------|",
            *rows,
        ]
        # Add details for critical/error findings
        details = [f for f in findings if f.get("severity") in ("critical", "error")]
        if details:
            section.append("")
            section.append("<details><summary>Show details & fixes</summary>\n")
            for f in details:
                section.append(f"**{f.get('title')}** — `{f.get('file')}`")
                section.append(f"> {f.get('detail','')}")
                if f.get("fix"):
                    section.append(f"\n💡 **Fix:** {f.get('fix')}")
                section.append("")
            section.append("</details>")
        sections.append("\n".join(section))

    # Complexity report
    complex_rows = []
    for c in analysis.get("complexity_report", []):
        vi = "✅" if c.get("verdict") == "ok" else ("⚠️" if c.get("verdict") == "warn" else "❌")
        complex_rows.append(f"| {vi} | `{c.get('file','')}` | `{c.get('method','')}` | {c.get('estimated_complexity','?')} |")

    complexity_section = ""
    if complex_rows:
        complexity_section = "\n".join([
            "### 🔀 Complexity Report",
            "| | File | Method | Complexity |",
            "|-|------|--------|-----------|",
            *complex_rows,
        ])

    # Test coverage section
    tcr = analysis.get("test_coverage_report", {})
    missing = tcr.get("missing_test_files", [])
    untested = tcr.get("untested_scenarios", [])

    test_section_lines = ["### 🧪 Test Coverage Report"]
    if missing:
        test_section_lines.append("**⚠️ Source files with NO corresponding test changes:**")
        for f in missing:
            test_section_lines.append(f"- `{f}`")
    if untested:
        test_section_lines.append("\n**Missing test scenarios:**")
        for s in untested:
            test_section_lines.append(f"- {s}")
    if not missing and not untested:
        test_section_lines.append("✅ All changed source files have corresponding test coverage.")
    test_section = "\n".join(test_section_lines)

    # Counts banner
    counts_line = (
        f"🔴 **{analysis.get('critical_count',0)} Critical** &nbsp;|&nbsp; "
        f"🟠 **{analysis.get('error_count',0)} Errors** &nbsp;|&nbsp; "
        f"🟡 **{analysis.get('warning_count',0)} Warnings** &nbsp;|&nbsp; "
        f"🔵 **{analysis.get('info_count',0)} Info**"
    )

    body = "\n\n".join(filter(None, [
        f"## ☕ Java 21 Code Review — {icon} {result.upper()}",
        f"**Branch diff:** `origin/{base}...HEAD` &nbsp;|&nbsp; **Java files reviewed:** {diff_data['total_java_files']}",
        counts_line,
        *sections,
        complexity_section,
        test_section,
        f"### Summary\n{analysis.get('summary', '')}",
        "> ⚠️ **Action required:** Fix all 🔴 Critical and 🟠 Error issues and push a new commit." if result == "failed" else "> ✅ Code quality checks passed.",
    ]))

    post_pr_comment(body)

    # Write outputs for aggregator
    _write_result(
        result,
        str(analysis.get("critical_count", 0)),
        str(analysis.get("error_count", 0)),
        str(analysis.get("warning_count", 0)),
        analysis.get("summary", ""),
    )

    if result == "failed":
        sys.exit(1)


def _write_result(result, critical, errors, warnings, summary):
    outputs = os.environ.get("GITHUB_OUTPUT") or os.environ.get("JENKINS_OUTPUTS", "/tmp/java_review.env")
    lines = [
        f"JAVA_RESULT={result}",
        f"JAVA_CRITICAL={critical}",
        f"JAVA_ERRORS={errors}",
        f"JAVA_WARNINGS={warnings}",
        f"JAVA_SUMMARY={summary[:300]}",
    ]
    # Write to file for Jenkins to read
    with open("/tmp/java_review_result.env", "w") as f:
        f.write("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    run()
