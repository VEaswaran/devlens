"""
scripts/setup_sonar_quality_gate.py
─────────────────────────────────────
Creates the "PR Quality Gate" in SonarQube with all conditions.
Run ONCE as admin after setting up the quality profile.

Usage:
    python scripts/setup_sonar_quality_gate.py ^
        --url http://localhost:9000 ^
        --token your-admin-token ^
        --project-key your-project-key
"""

import sys
import argparse
import requests

# ================================================================
# Quality Gate Conditions
# ================================================================
# period=1 means "on new code" (the diff since last analysis / PR diff)
# period=0 means "overall project"
# ================================================================

GATE_CONDITIONS = [
    # ── New Code (period=1) — most important for PRs ─────────────
    {
        "metric":    "new_coverage",
        "op":        "LT",      # Less Than → fail
        "error":     "80",      # Must have >= 80% coverage on new code
        "period":    "1",
        "label":     "New code coverage >= 80%",
    },
    {
        "metric":    "new_branch_coverage",
        "op":        "LT",
        "error":     "75",
        "period":    "1",
        "label":     "New branch coverage >= 75%",
    },
    {
        "metric":    "new_duplicated_lines_density",
        "op":        "GT",      # Greater Than → fail
        "error":     "3",       # Must have <= 3% duplication on new code
        "period":    "1",
        "label":     "New code duplication <= 3%",
    },
    {
        "metric":    "new_blocker_violations",
        "op":        "GT",
        "error":     "0",       # Zero tolerance on new BLOCKER issues
        "period":    "1",
        "label":     "No new BLOCKER issues",
    },
    {
        "metric":    "new_critical_violations",
        "op":        "GT",
        "error":     "0",       # Zero tolerance on new CRITICAL issues
        "period":    "1",
        "label":     "No new CRITICAL issues",
    },
    {
        "metric":    "new_major_violations",
        "op":        "GT",
        "error":     "5",       # Allow up to 5 new MAJOR issues
        "period":    "1",
        "label":     "New MAJOR issues <= 5",
    },
    {
        "metric":    "new_sqale_debt_ratio",
        "op":        "GT",
        "error":     "5",       # New technical debt ratio <= 5%
        "period":    "1",
        "label":     "New tech debt ratio <= 5%",
    },
    # ── Security Hotspots ────────────────────────────────────────
    {
        "metric":    "new_security_hotspots_reviewed",
        "op":        "LT",
        "error":     "100",     # All new security hotspots must be reviewed
        "period":    "1",
        "label":     "New security hotspots reviewed = 100%",
    },
    # ── Overall project (non-period) ─────────────────────────────
    {
        "metric":    "blocker_violations",
        "op":        "GT",
        "error":     "0",       # No BLOCKER issues in whole project
        "period":    None,
        "label":     "No BLOCKER issues overall",
    },
]


def create_quality_gate(base_url: str, token: str, gate_name: str) -> str:
    """Create or find the quality gate and return its ID."""
    print(f"\n{'='*60}")
    print(f"Setting up Quality Gate: '{gate_name}'")

    # Check if it already exists
    r = requests.get(
        f"{base_url}/api/qualitygates/list",
        auth=(token, ""), timeout=15
    )
    r.raise_for_status()
    for gate in r.json().get("qualitygates", []):
        if gate["name"] == gate_name:
            gid = str(gate["id"])
            print(f"  ✓ Quality gate exists (id: {gid}) — will update conditions")
            # Delete existing conditions so we can re-add cleanly
            _delete_all_conditions(base_url, token, gid)
            return gid

    # Create new gate
    r = requests.post(
        f"{base_url}/api/qualitygates/create",
        data={"name": gate_name},
        auth=(token, ""), timeout=15
    )
    r.raise_for_status()
    gid = str(r.json()["id"])
    print(f"  ✓ Created quality gate (id: {gid})")
    return gid


def _delete_all_conditions(base_url: str, token: str, gate_id: str):
    """Remove all conditions from a gate (to replace with new ones)."""
    r = requests.get(
        f"{base_url}/api/qualitygates/show",
        params={"id": gate_id},
        auth=(token, ""), timeout=15
    )
    for cond in r.json().get("conditions", []):
        requests.post(
            f"{base_url}/api/qualitygates/delete_condition",
            data={"id": cond["id"]},
            auth=(token, ""), timeout=15
        )


def add_conditions(base_url: str, token: str, gate_id: str):
    """Add all conditions to the quality gate."""
    print(f"\n{'='*60}")
    print("Adding quality gate conditions...\n")

    for cond in GATE_CONDITIONS:
        payload = {
            "gateId": gate_id,
            "metric": cond["metric"],
            "op":     cond["op"],
            "error":  cond["error"],
        }
        if cond.get("period"):
            payload["period"] = cond["period"]

        r = requests.post(
            f"{base_url}/api/qualitygates/create_condition",
            data=payload,
            auth=(token, ""), timeout=15
        )
        icon = "✅" if r.ok else "❌"
        scope = f"[new code]" if cond.get("period") == "1" else "[overall]"
        print(f"  {icon} {scope:12s} {cond['label']}")
        if not r.ok:
            print(f"       Error: {r.text[:100]}")


def set_as_default_gate(base_url: str, token: str, gate_id: str):
    r = requests.post(
        f"{base_url}/api/qualitygates/set_as_default",
        data={"id": gate_id},
        auth=(token, ""), timeout=15
    )
    if r.ok:
        print(f"\n  ✓ Set as default quality gate")


def assign_gate_to_project(base_url: str, token: str, gate_id: str, project_key: str):
    if not project_key:
        return
    r = requests.post(
        f"{base_url}/api/qualitygates/select",
        data={"gateId": gate_id, "projectKey": project_key},
        auth=(token, ""), timeout=15
    )
    if r.ok:
        print(f"  ✓ Quality gate assigned to project '{project_key}'")
    else:
        print(f"  ⚠️  Could not assign to project: {r.text[:80]}")


def main():
    parser = argparse.ArgumentParser(description="Create SonarQube Quality Gate for Java 21 PRs")
    parser.add_argument("--url",         default="http://localhost:9000",  help="SonarQube URL")
    parser.add_argument("--token",       required=True,                    help="Admin token")
    parser.add_argument("--gate-name",   default="PR Quality Gate",        help="Quality gate name")
    parser.add_argument("--project-key", default="",                       help="Assign to project key")
    parser.add_argument("--set-default", action="store_true",              help="Set as default gate")
    args = parser.parse_args()

    base_url = args.url.rstrip("/")

    print(f"\n🔗 Connecting to {base_url}...")
    try:
        r = requests.get(f"{base_url}/api/system/status", auth=(args.token, ""), timeout=10)
        print(f"  ✓ SonarQube {r.json().get('version','?')} connected")
    except Exception as e:
        print(f"  ✗ Cannot connect: {e}"); sys.exit(1)

    gate_id = create_quality_gate(base_url, args.token, args.gate_name)
    add_conditions(base_url, args.token, gate_id)

    if args.set_default:
        set_as_default_gate(base_url, args.token, gate_id)
    if args.project_key:
        assign_gate_to_project(base_url, args.token, gate_id, args.project_key)

    print(f"\n{'='*60}")
    print(f"✅ Quality Gate '{args.gate_name}' ready!")
    print(f"   View at: {base_url}/quality_gates")
    print(f"\n   {len(GATE_CONDITIONS)} conditions configured:")
    print(f"   • Coverage:     >= 80% on new code")
    print(f"   • Branches:     >= 75% on new code")
    print(f"   • Duplication:  <= 3%  on new code")
    print(f"   • BLOCKERs:     = 0    (new + overall)")
    print(f"   • CRITICALs:    = 0    on new code")
    print(f"   • MAJOR issues: <= 5   on new code")
    print(f"   • Security:     100%   hotspots reviewed")


if __name__ == "__main__":
    main()
