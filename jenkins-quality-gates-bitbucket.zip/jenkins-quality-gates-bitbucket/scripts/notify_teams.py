"""
scripts/notify_teams.py
────────────────────────
Sends MS Teams Adaptive Card when PR review completes.
@mentions the commit author using Teams email mapping from config.
"""

import os
import sys
import json
import yaml
import requests
from pathlib import Path


def load_user_map() -> dict:
    try:
        workspace = os.environ.get("WORKSPACE") or "."
        cfg_path  = Path(workspace) / "config" / "agent-config.yml"
        cfg = yaml.safe_load(cfg_path.read_text())
        return cfg.get("notifications", {}).get("ms_teams", {}).get("user_mapping", {})
    except Exception:
        return {}


def run():
    webhook = os.environ.get("MS_TEAMS_WEBHOOK_URL", "")
    if not webhook:
        print("MS_TEAMS_WEBHOOK_URL not set — skipping.")
        return

    # Read aggregated result
    agg = {}
    try:
        with open("/tmp/aggregate_result.env") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    agg[k] = v
    except FileNotFoundError:
        pass

    overall       = agg.get("OVERALL_RESULT", os.environ.get("OVERALL_RESULT", "unknown"))
    failed_agents = agg.get("FAILED_AGENTS",  os.environ.get("FAILED_AGENTS", ""))
    java_crit     = agg.get("JAVA_CRITICAL",  "0")
    java_err      = agg.get("JAVA_ERRORS",    "0")

    pr_number = os.environ.get("PR_NUMBER", "?")
    pr_title  = os.environ.get("PR_TITLE",  "PR")[:70]
    pr_author = os.environ.get("PR_AUTHOR", "developer")
    pr_branch = os.environ.get("PR_BRANCH", "")
    pr_sha    = os.environ.get("PR_SHA", "")[:7]
    ticket_id = os.environ.get("TICKET_ID", "—")
    repo      = os.environ.get("GITHUB_REPOSITORY", "")
    server    = os.environ.get("GITHUB_SERVER_URL", "https://github.com")
    build_url = os.environ.get("BUILD_URL", "")

    pr_url  = f"{server}/{repo}/pull/{pr_number}" if repo else ""
    is_pass = overall == "passed"

    # Teams @mention
    user_map    = load_user_map()
    teams_email = user_map.get(pr_author)
    mention_text = f"<at>{pr_author}</at>" if teams_email else f"@{pr_author}"

    # Adaptive card body items
    items = [
        # Header container
        {
            "type": "Container",
            "style": "good" if is_pass else "attention",
            "bleed": True,
            "items": [{
                "type": "TextBlock",
                "text": "✅  ALL AGENTS PASSED" if is_pass else "❌  REVIEW FAILED",
                "weight": "Bolder",
                "size": "Medium",
                "color": "Light",
            }]
        },
        # Facts
        {
            "type": "FactSet",
            "spacing": "Medium",
            "facts": [
                {"title": "📋 PR",       "value": f"[#{pr_number} — {pr_title}]({pr_url})"},
                {"title": "👤 Author",   "value": pr_author},
                {"title": "🔀 Branch",   "value": pr_branch},
                {"title": "🔖 Commit",   "value": f"`{pr_sha}`"},
                {"title": "🎫 Ticket",   "value": ticket_id},
                {"title": "☕ Java",     "value": f"🔴 {java_crit} critical · 🟠 {java_err} errors"},
            ],
        },
        {"type": "Separator"},
    ]

    if not is_pass and failed_agents:
        items.append({
            "type": "TextBlock",
            "text": f"**Failed agents:** {failed_agents}",
            "color": "Attention",
            "wrap": True,
        })

    items.append({
        "type": "TextBlock",
        "text": (
            f"{mention_text} — your PR requires changes. "
            "Review each agent comment on the PR and push a fix commit."
        ) if not is_pass else (
            f"{mention_text} — all AI checks passed! Awaiting human reviewer approval."
        ),
        "wrap": True,
        "color": "Attention" if not is_pass else "Good",
        "spacing": "Medium",
    })

    card = {
        "type": "message",
        "attachments": [{
            "contentType": "application/vnd.microsoft.card.adaptive",
            "contentUrl": None,
            "content": {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.4",
                "msteams": {
                    "width": "Full",
                    **({"entities": [{"type": "mention", "text": f"<at>{pr_author}</at>",
                                      "mentioned": {"id": teams_email, "name": pr_author}}]}
                       if teams_email else {}),
                },
                "body": items,
                "actions": [
                    {"type": "Action.OpenUrl", "title": "🔍 View PR",     "url": pr_url},
                    {"type": "Action.OpenUrl", "title": "📋 Jenkins Log", "url": build_url},
                ],
            }
        }]
    }

    r = requests.post(webhook, json=card, timeout=15)
    if r.ok:
        print(f"✅ Teams notification sent (result={overall})")
    else:
        print(f"Teams webhook failed {r.status_code}: {r.text}")
        sys.exit(1)


if __name__ == "__main__":
    run()
