"""
scripts/setup_sonar_rules.py
─────────────────────────────
One-time setup script — run this ONCE with admin credentials
to create the "Java 21 Standards" Quality Profile and
configure all rules with correct severities.

Usage:
    python scripts/setup_sonar_rules.py ^
        --url http://localhost:9000 ^
        --token your-admin-token ^
        --profile-name "Java 21 Standards"
"""

import sys
import time
import argparse
import requests

# ================================================================
# ALL RULES — grouped by category
# Format: (sonar_rule_key, severity, description, parameters)
# ================================================================

RULES = {

    # ── ERROR HANDLING (BLOCKER / CRITICAL) ─────────────────────
    "error_handling": [
        # Empty catch block — zero tolerance
        ("java:S108",   "BLOCKER",  "Empty catch block",
         {}),
        # InterruptedException swallowed
        ("java:S2142",  "BLOCKER",  "InterruptedException should not be ignored",
         {}),
        # Exception not rethrown or logged — just swallowed
        ("java:S1166",  "CRITICAL", "Exception handlers must preserve or log the original exception",
         {}),
        # Throwing generic Exception/RuntimeException/Throwable
        ("java:S112",   "CRITICAL", "Generic exceptions should not be thrown",
         {}),
        # Catching generic Exception (too broad)
        ("java:S2221",  "CRITICAL", "Exception should not be caught when not required by the called code",
         {}),
        # Error class should not be caught
        ("java:S1181",  "CRITICAL", "Throwable and Error should not be caught",
         {}),
        # Exceptions should not be ignored in finally blocks
        ("java:S1143",  "BLOCKER",  "Jump statements should not occur in finally blocks",
         {}),
        # Return inside finally block
        ("java:S1141",  "CRITICAL", "Try-catch blocks should not be nested",
         {}),
    ],

    # ── NULL SAFETY (BLOCKER / CRITICAL) ────────────────────────
    "null_safety": [
        # Null pointer dereference
        ("java:S2259",  "BLOCKER",  "Null pointers should not be dereferenced",
         {}),
        # Optional.get() without isPresent() check
        ("java:S3655",  "BLOCKER",  "Optional value should only be accessed after calling isPresent()",
         {}),
        # NullPointerException explicitly thrown
        ("java:S1695",  "CRITICAL", "NullPointerException should not be thrown explicitly",
         {}),
        # Returning null from method that may have been assumed non-null
        ("java:S2637",  "CRITICAL", "Non-null return values should not be null",
         {}),
    ],

    # ── CYCLOMATIC & COGNITIVE COMPLEXITY (CRITICAL) ────────────
    "complexity": [
        # Cyclomatic complexity > 10
        ("java:S1541",  "CRITICAL", "Cyclomatic complexity should not be too high",
         {"max": "10"}),
        # Cognitive complexity > 15
        ("java:S3776",  "CRITICAL", "Cognitive complexity should not be too high",
         {"threshold": "15"}),
        # Deeply nested if statements (> 3 levels)
        ("java:S134",   "MAJOR",    "Control flow statements should not be nested too deeply",
         {"max": "3"}),
        # Method too long (> 40 lines excluding blank/comments)
        ("java:S138",   "MAJOR",    "Methods should not have too many lines",
         {"max": "40"}),
        # File/class too long
        ("java:S2972",  "MAJOR",    "Inner classes should not have too many lines",
         {"max": "200"}),
        # Too many parameters
        ("java:S107",   "MAJOR",    "Methods should not have too many parameters",
         {"max": "5"}),
        # Boolean expression too complex
        ("java:S1067",  "MAJOR",    "Expressions should not be too complex",
         {"max": "3"}),
    ],

    # ── CODE SMELLS (MAJOR / MINOR) ──────────────────────────────
    "code_smells": [
        # God class — too many methods
        ("java:S1448",  "MAJOR",    "Classes should not have too many methods",
         {"maximumMethodThreshold": "20", "countNonpublicMethods": "true"}),
        # Too many fields
        ("java:S1820",  "MAJOR",    "Classes with only static members should not be instantiated",
         {}),
        # Class coupled to too many other classes
        ("java:S1200",  "MAJOR",    "Classes should not be coupled to too many other classes",
         {"max": "20"}),
        # Unused private field
        ("java:S1068",  "MAJOR",    "Unused private fields should be removed",
         {}),
        # Unused local variable (dead store)
        ("java:S1854",  "MAJOR",    "Dead stores should be removed",
         {}),
        # Unused method parameter
        ("java:S1172",  "MAJOR",    "Unused method parameters should be removed",
         {}),
        # Duplicate string literal > 3 times
        ("java:S1192",  "MAJOR",    "String literals should not be duplicated",
         {"threshold": "3"}),
        # Magic numbers
        ("java:S109",   "MINOR",    "Magic numbers should not be used",
         {}),
        # Commented-out code
        ("java:S125",   "MAJOR",    "Sections of code should not be commented out",
         {}),
        # TODO comment (must be a ticket)
        ("java:S1135",  "INFO",     "Track uses of \"TODO\" tags",
         {}),
        # FIXME comment — more urgent than TODO
        ("java:S1134",  "MAJOR",    "Track uses of \"FIXME\" tags",
         {}),
        # Field name hides parent class field
        ("java:S2387",  "MAJOR",    "Child class fields should not shadow parent class fields",
         {}),
        # Field duplicates class name
        ("java:S1700",  "MINOR",    "A field should not duplicate the name of its containing class",
         {}),
        # Utility class should not be instantiated
        ("java:S1118",  "MAJOR",    "Utility classes should not have public constructors",
         {}),
        # Array covariance — unsafe cast risk
        ("java:S3067",  "MAJOR",    "Getters and setters should access the expected fields",
         {}),
    ],

    # ── JAVA 21 BEST PRACTICES (MAJOR / MINOR) ──────────────────
    "java21_practices": [
        # == on boxed primitives (Integer, Long, etc.)
        ("java:S4973",  "CRITICAL", "Strings and Boxed types should be compared using equals()",
         {}),
        # Mutable members exposed
        ("java:S2384",  "MAJOR",    "Mutable members should not be stored or returned directly",
         {}),
        # clone() should not be used
        ("java:S2975",  "MAJOR",    "\"clone\" should not be overridden",
         {}),
        # instanceof followed by cast — use pattern matching
        ("java:S5194",  "MINOR",    "Pattern matching should be used",
         {}),
        # StringBuilder in a loop — potential performance issue
        ("java:S1643",  "MAJOR",    "Strings should not be concatenated using '+' in a loop",
         {}),
        # Collection.isEmpty() vs size() == 0
        ("java:S1155",  "MINOR",    "Collection.isEmpty() should be used to test for emptiness",
         {}),
        # Stream API collect vs explicit loop
        ("java:S3864",  "MINOR",    "\"Stream.peek\" should be used with caution",
         {}),
        # Use of deprecated APIs
        ("java:S1874",  "MAJOR",    "Deprecated code should be removed",
         {}),
        # Raw types (non-generic)
        ("java:S3740",  "MAJOR",    "Unchecked casts should not be done without reason",
         {}),
        # Thread.sleep in tests
        ("java:S2925",  "MAJOR",    "\"Thread.sleep\" should not be used in tests",
         {}),
        # System.out.println in production code
        ("java:S106",   "MAJOR",    "Standard outputs should not be used directly to log anything",
         {}),
        # Sonar — use logger
        ("java:S2629",  "MINOR",    "Logging arguments should not require evaluation",
         {}),
    ],

    # ── SECURITY (BLOCKER / CRITICAL) ───────────────────────────
    "security": [
        # Hardcoded credentials
        ("java:S2068",  "BLOCKER",  "Credentials should not be hard-coded",
         {}),
        # SQL injection
        ("java:S3649",  "BLOCKER",  "Database queries should not be vulnerable to injection",
         {}),
        # Path traversal
        ("java:S2083",  "CRITICAL", "I/O function calls should not be vulnerable to path injection",
         {}),
        # XML external entity (XXE)
        ("java:S2755",  "BLOCKER",  "XML parsers should not be vulnerable to XXE attacks",
         {}),
        # Random number should be secure
        ("java:S2245",  "CRITICAL", "Using pseudorandom number generators is security-sensitive",
         {}),
        # HTTP requests should be safe
        ("java:S5144",  "CRITICAL", "Server-side requests should not be vulnerable to SSRF",
         {}),
    ],
}


# ================================================================
# Setup Script
# ================================================================

def create_quality_profile(base_url: str, token: str, profile_name: str, language: str = "java") -> str:
    """Create a new quality profile and return its key."""
    print(f"\n{'='*60}")
    print(f"Creating Quality Profile: '{profile_name}'")

    # Check if profile already exists
    r = requests.get(
        f"{base_url}/api/qualityprofiles/search",
        params={"language": language, "qualityProfile": profile_name},
        auth=(token, ""), timeout=15
    )
    existing = r.json().get("profiles", [])
    if existing:
        key = existing[0]["key"]
        print(f"  ✓ Profile already exists (key: {key}) — will update rules")
        return key

    # Create new profile
    r = requests.post(
        f"{base_url}/api/qualityprofiles/create",
        data={"name": profile_name, "language": language},
        auth=(token, ""), timeout=15
    )
    r.raise_for_status()
    key = r.json()["profile"]["key"]
    print(f"  ✓ Created profile (key: {key})")
    return key


def activate_rules(base_url: str, token: str, profile_key: str):
    """Activate all rules in the quality profile."""
    print(f"\n{'='*60}")
    print("Configuring rules...")

    total   = sum(len(rules) for rules in RULES.values())
    done    = 0
    skipped = 0

    for category, rules in RULES.items():
        print(f"\n  📋 {category.upper().replace('_', ' ')}")
        for rule_key, severity, description, params in rules:
            payload = {
                "key":      profile_key,
                "rule":     rule_key,
                "severity": severity,
            }
            # Add rule parameters if any
            for i, (pk, pv) in enumerate(params.items()):
                payload[f"params"] = f"{pk}={pv}"

            r = requests.post(
                f"{base_url}/api/qualityprofiles/activate_rule",
                data=payload,
                auth=(token, ""), timeout=15
            )
            done += 1
            if r.status_code == 200:
                sev_icon = {"BLOCKER":"🔴","CRITICAL":"🟠","MAJOR":"🟡","MINOR":"🔵","INFO":"⚪"}.get(severity,"⚪")
                print(f"    {sev_icon} [{severity:8s}] {rule_key:20s} — {description[:55]}")
            elif r.status_code == 404:
                print(f"    ⚠️  SKIP (not found): {rule_key}")
                skipped += 1
            else:
                print(f"    ❌ FAILED {r.status_code}: {rule_key} — {r.text[:80]}")

            time.sleep(0.1)  # be gentle with the API

    print(f"\n  Activated: {done - skipped}/{total}  |  Skipped (not in this edition): {skipped}")


def set_as_default(base_url: str, token: str, profile_key: str, language: str = "java"):
    """Set this profile as the default for Java projects."""
    r = requests.post(
        f"{base_url}/api/qualityprofiles/set_default",
        data={"language": language, "qualityProfile": profile_key},
        auth=(token, ""), timeout=15
    )
    if r.ok:
        print(f"\n  ✓ Set as default Java quality profile")
    else:
        print(f"\n  ⚠️  Could not set as default: {r.text}")


def assign_to_project(base_url: str, token: str, project_key: str, profile_name: str, language: str = "java"):
    """Assign the quality profile to a specific project."""
    if not project_key:
        return
    r = requests.post(
        f"{base_url}/api/qualityprofiles/add_project",
        data={
            "project":        project_key,
            "qualityProfile": profile_name,
            "language":       language,
        },
        auth=(token, ""), timeout=15
    )
    if r.ok:
        print(f"  ✓ Profile assigned to project '{project_key}'")
    else:
        print(f"  ⚠️  Could not assign to project: {r.text[:100]}")


def main():
    parser = argparse.ArgumentParser(description="Configure SonarQube quality profile for Java 21")
    parser.add_argument("--url",          default="http://localhost:9000",  help="SonarQube URL")
    parser.add_argument("--token",        required=True,                     help="Admin token or admin:password")
    parser.add_argument("--profile-name", default="Java 21 Standards",       help="Quality profile name")
    parser.add_argument("--project-key",  default="",                        help="Assign to this project key")
    parser.add_argument("--set-default",  action="store_true",               help="Set as default Java profile")
    args = parser.parse_args()

    base_url = args.url.rstrip("/")

    # Verify connection
    print(f"\n🔗 Connecting to SonarQube at {base_url}...")
    try:
        r = requests.get(f"{base_url}/api/system/status", auth=(args.token, ""), timeout=10)
        r.raise_for_status()
        status = r.json()
        print(f"  ✓ Connected — SonarQube {status.get('version','?')} ({status.get('status','?')})")
    except Exception as e:
        print(f"  ✗ Cannot connect: {e}")
        sys.exit(1)

    # Run setup
    profile_key = create_quality_profile(base_url, args.token, args.profile_name)
    activate_rules(base_url, args.token, profile_key)

    if args.set_default:
        set_as_default(base_url, args.token, profile_key)

    if args.project_key:
        assign_to_project(base_url, args.token, args.project_key, args.profile_name)

    rule_count = sum(len(r) for r in RULES.values())
    print(f"\n{'='*60}")
    print(f"✅ Quality Profile '{args.profile_name}' configured!")
    print(f"   Total rules: {rule_count}")
    print(f"   View at:     {base_url}/profiles")
    print(f"\nNext step: run setup_sonar_quality_gate.py to create the Quality Gate")


if __name__ == "__main__":
    main()
