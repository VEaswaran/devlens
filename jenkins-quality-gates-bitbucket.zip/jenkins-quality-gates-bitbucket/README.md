# 🤖 Jenkins Quality Gates — Java 21 + Gradle + SonarQube + Bitbucket Cloud

Same 3-gate pipeline, adapted for **Bitbucket Cloud** (bitbucket.org).

```
GATE 1 ──► GATE 2 ──► GATE 3 ──► AI Review ──► Teams Notify
Unit +      Integration  SonarQube
Coverage    Tests        Analysis
```

---

## What's different from the GitHub version

| | GitHub | Bitbucket Cloud |
|---|---|---|
| Auth | Personal Access Token | **API token** + account **email** (Basic Auth) |
| Build status API | `POST /repos/{owner}/{repo}/statuses/{sha}` | `POST /2.0/repositories/{workspace}/{repo}/commit/{sha}/statuses/build` |
| Status states | `success/failure/pending` | `SUCCESSFUL/FAILED/INPROGRESS/STOPPED` |
| PR comments | issue comments API | `POST /2.0/repositories/{ws}/{repo}/pullrequests/{id}/comments` |
| Labels | native label API | **not supported** — Bitbucket Cloud PRs have no label API (no-op in code) |
| Jenkins plugin | GitHub Integration | **Bitbucket Branch Source Plugin** |
| SonarQube PR decoration | works on Community Edition | **requires Developer Edition+** (Community Edition still runs the Quality Gate — it just can't post inline PR comments) |

---

## ⚠️ Authentication — the #1 gotcha

Bitbucket Cloud API tokens (the current auth method, replacing deprecated App Passwords) use:
- **Username** = your Atlassian account **email address** (not your Bitbucket username/handle)
- **Password** = the API token

```powershell
# Create one at:
# https://id.atlassian.com/manage-profile/security/api-tokens
# → Create API token → scope: Bitbucket → select "Pull requests: Write",
#   "Repositories: Write", "Webhooks: Read and write"
```

Store both as separate Jenkins credentials: `BITBUCKET_EMAIL` and `BITBUCKET_TOKEN`.

---

## Setup order

### 1. Jenkins plugins
Manage Jenkins → Plugins → install:
- **Bitbucket Branch Source Plugin** (enables `CHANGE_ID`, `CHANGE_AUTHOR`, etc. for PR builds — same variable names the GitHub version used)
- SonarQube Scanner
- JaCoCo, JUnit, Pipeline (same as before)

### 2. Jenkins credentials
Manage Jenkins → Credentials → Global → Add:

| ID | Type | Value |
|----|------|-------|
| `BITBUCKET_EMAIL` | Secret text | Your Atlassian account email |
| `BITBUCKET_TOKEN` | Secret text | API token from step above |
| `SONAR_TOKEN` | Secret text | SonarQube token |
| `MS_TEAMS_WEBHOOK_URL` | Secret text | Teams webhook |
| `ANTHROPIC_API_KEY` | Secret text | Claude API key |
| `JIRA_TOKEN`, `JIRA_EMAIL`, `JIRA_BASE_URL` | Secret text | Jira access |

### 3. Create a Bitbucket App/OAuth consumer for the webhook (optional but recommended)
Instead of a manual webhook, use the **Bitbucket Branch Source Plugin's** built-in
Bitbucket Cloud connection:

Manage Jenkins → System → Bitbucket Endpoints → Add:
```
Name:         Bitbucket Cloud
Bitbucket Cloud: (default, no URL needed — it's always bitbucket.org)
```

### 4. Create the multibranch pipeline job
```
New Item → Multibranch Pipeline
Branch Sources → Add → Bitbucket
  Credentials:   (create a "Username with password" cred using
                  BITBUCKET_EMAIL as username, BITBUCKET_TOKEN as password)
  Workspace:     your-workspace
  Repository:    your-repo

Behaviors → add "Discover pull requests from origin" (and "from forks" if needed)
Build Configuration → by Jenkinsfile → Jenkinsfile
```

This automatically creates a webhook in Bitbucket pointing back to Jenkins —
**no manual webhook setup needed** if Jenkins is reachable from Bitbucket
(use ngrok for local testing, same as before).

### 5. Manual webhook (if not using the multibranch job / plugin auto-registration)
Bitbucket repo → Repository settings → Webhooks → Add webhook:
```
Title:  Jenkins CI
URL:    https://your-ngrok-url.ngrok-free.app/bitbucket-hook/
Triggers:
  ✓ Pull Request: Created
  ✓ Pull Request: Updated
  ✓ Pull Request: Merged (optional, for post-merge notifications)
```

### 6. Edit the Jenkinsfile
```groovy
BITBUCKET_WORKSPACE = 'your-workspace'   // ← the org/workspace slug in the URL
BITBUCKET_REPO_SLUG = 'your-repo'        // ← repo slug
SONAR_PROJECT_KEY   = 'your-project-key'
```

### 7. Branch merge checks (Bitbucket's equivalent of GitHub branch protection)
Repo → Repository settings → Branch permissions → Add a branch permission rule for `main`/`develop`:
```
✓ Prevent changes to matching branches
  Merge checks:
    ✓ "Check for successful builds" — minimum number of successful builds: 3
      (Gate 1, Gate 2, Gate 3 — Bitbucket counts each distinct status `key`
       posted via the API as a separate build check)
```
Since each gate posts a distinct `key` (`gate-1-unit-coverage`, `gate-2-integration`,
`gate-3-sonarqube`), Bitbucket's merge check will show all 3 individually on the PR.

### 8. SonarQube — Bitbucket Cloud integration (Developer Edition+ only)
If you're on SonarQube Developer Edition or higher, connect it for inline PR
decoration (SonarQube posts its own comments directly on the PR diff):

SonarQube → Administration → DevOps Platform Integrations → Bitbucket → Add:
```
Configuration name:  Bitbucket Cloud
Workspace:           your-workspace
OAuth key/secret:     (create at Bitbucket → Workspace settings → OAuth consumers)
```
Then in project settings → set the Bitbucket repository link.

**On Community Edition**, skip this — the Jenkinsfile's own `postBitbucketPRComment()`
calls already post a pass/fail summary comment on the PR regardless, so gate
enforcement and visibility both work without the Developer Edition integration.
It's only the fancy inline-diff annotations from SonarQube itself that you'd miss.

---

## File structure

```
build.gradle / build.gradle.kts   # unchanged from the Gradle setup
Jenkinsfile                        # Bitbucket Cloud API calls (status + PR comments)
agents/
  shared/agent_utils.py            # Bitbucket Cloud REST API (was GitHub API)
  java_review_agent.py             # unchanged — reviews via git diff, posts via agent_utils
  spanner_agent.py                 # unchanged
  ticket_validator.py              # unchanged (Jira is independent of Git host)
  aggregator.py                    # unchanged — set_label() becomes a no-op automatically
scripts/
  notify_teams.py                  # unchanged
  setup_sonar_rules.py             # unchanged — talks to SonarQube API directly
  setup_sonar_quality_gate.py      # unchanged
config/agent-config.yml            # unchanged
```

---

## Testing the Bitbucket API calls locally

```powershell
$env:BITBUCKET_EMAIL      = "you@company.com"
$env:BITBUCKET_TOKEN      = "your-api-token"
$env:BITBUCKET_WORKSPACE  = "your-workspace"
$env:BITBUCKET_REPO_SLUG  = "your-repo"
$env:PR_NUMBER            = "42"
$env:PR_SHA               = "abc123..."
$env:WORKSPACE             = (Get-Location).Path

python agents/java_review_agent.py
```
